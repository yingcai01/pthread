#include <iostream>

using namespace std;

void Insert_sort(int *a,int length){
    int len = length;
    int i,j;
    for(i = 1;i<len;i++){
        int key = a[i];
        for(j = i-1;j >= 0 && a[j] > key;j--){
            a[j+1] = a[j];
        }
        a[j+1] = key;
    }
}
int main(int argc,char *argv[]){
    int a[7] = {3,2,5,1,6,4,7};
    Insert_sort(a,7);
    int i;
    for(i=0;i<7;i++)
        cout << a[i] <<" ";
    cout << endl;
    return 0;
}
