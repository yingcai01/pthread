#include <iostream>

using namespace std;

void Quik_sort(int *a,int left,int right){
    if(left >= right)
        return;
    int i = left;
    int j = right;
    int base = a[left];

    while(i < j){
        while(i < j && a[j] >= base)
            j--;
        while(i < j && a[i] <= base)
            i++;
        if(i < j){
            int tmp = a[i];
            a[i] = a[j];
            a[j] = tmp;
        }
    }
    a[left] = a[i];
    a[i] = base;

    Quik_sort(a,left,i);
    Quik_sort(a,i+1,right);

}
int main(int argc,char *argv[]){
    int a[7] = {1,2,5,3,4,68,10};
    int i;
    for(i=0;i<7;i++)
        cout<<a[i]<<" ";
    cout<<endl;
    Quik_sort(a,0,6);
    for(i=0;i<7;i++)
        cout<<a[i]<<" ";
    cout<<endl;
    return 0;
}
