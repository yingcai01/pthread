#include <iostream>

using namespace std;
//建堆，传入参数为数组，根节点，数组长度
void heap_init(int *a,int root,int len){
    int lchild = 2*root + 1;
    int rchild = 2*root + 2;
    int largest = root;

    if(lchild < len && a[lchild] > a[largest])
        largest = lchild;
    if(rchild < len && a[rchild] > a[largest])
        largest = rchild;

    if(largest != root){
        swap(a[largest],a[root]);
        heap_init(a,largest,len);
    }

}

void Heap_sort(int *a,int len){

    int i;
    for(i = len/2-1;i >= 0 ;i--){
        heap_init(a,i,len);
        //计算len-1 = 2i+1;i表示完全二叉树的最后一个父节点，
        //这里是从最后一个不是叶子节点的父节点开始构建堆
    }
    /*
    for(i = len-1;i >= 0 ;i--){
        swap(a[0],a[i]);
        heap_init(a,0,i);
    }*/
    for(i = 0;i<len-1;i++){
        swap(a[0],a[len-1-i]);
        heap_init(a,0,len-1-i);
    }
}
int main(int argc,char *argv[]){
    int a[7] = {32,4,2,545,45,1,7};
    Heap_sort(a,7);
    int i;
    for(i = 0;i<7;i++){
        cout<<a[i]<< " ";
    }
    cout <<endl;
    return 0;
}
