#include <iostream>

using namespace std;

void Merge(int a[],int left,int mid,int right){
    /*
    int p = mid - left +1;
    int q = right - mid;
    int *L = new int[p+1];
    int *R = new int[q+1];

    int i,j,k;
    for(i = 0;i < p;i++){
        L[i] = a[left+i];
    }
    for(j = 0;j < q;j++){
        R[j] = a[mid+j+1];
    }
    L[p] = 11111111;
    R[q] = 11111111;
    for(i=0,j=0,k=left;k <= right; k++){
        if(L[i] <= R[j])
            a[k] = L[i++];
        else
            a[k] = R[j++];
    }

    delete []L;
    delete []R;
    */
    int sum = right - left + 1;
    int *temp = new int[sum];
    int i = left;
    int j = mid+1;
    int k = 0;
    while(i <= mid && j <= right){
        if(a[i] <= a[j])
            temp[k++] = a[i++];
        else
            temp[k++] = a[j++];
    }
    //上面循环跳出，则有一个区间就赋值完了，另一个区间直接追加在新数组后面
    while(i <= mid)
        temp[k++] = a[i++];
    while(j <= right)
        temp[k++] = a[j++];
    //
    for(i=left,k=0;k<sum;)
        a[i++] = temp[k++];
}

void Merge_sort(int a[],int left,int right){

    if(left < right){
        int mid = (left + right)/2;
        Merge_sort(a,left,mid);//一直分区，直到分到最少的两个
        Merge_sort(a,mid+1,right);//
        Merge(a,left,mid,right);
    }
}
int main(int argc,char *argv[]){
    int i;
    int a[11] = {2,5,8,8,66,33,2,12,0,56,20};
    for(i=0;i<11;i++)
        cout <<a[i]<<" ";
    cout<<endl;
    Merge_sort(a,0,10);
    for(i=0;i<11;i++)
        cout<<a[i]<<" ";
    cout<<endl;
    return 0;
}
