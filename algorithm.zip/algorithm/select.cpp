#include <iostream>

void select_sort(int *a,int len){
    int i,j;
    for(i=0;i<len;i++){
        for(j = 0;j<len-i;j++){
            if(a[j]>a[j+1])
        }
    }
};
