#include <iostream>
#include "head.h"
void print1();
void test3();
pthread_t test;
void *pthread_test(void *);


bool my_strstr(const char *str,const char *substr,int *sum){
    int i,j;
    int len = strlen(substr)+1;
    int str_len = strlen(str)+1;
    int ret = 1;

    for(i=0;i< str_len;i++){
        j=0;
        if(str[i] == substr[j]) {
            int x = i;
            ret = 1;
            for (; j < len && x+j < str_len; j++) {
                if(str[x+j] == substr[j])
                    ret++;
            }
            if(ret == len){
                (*sum)++;
                cout << substr << ":" << x << endl;
                //return true;
            }
        }
    }
    cout << "substr not find..." << endl;
    return false;
}
int main() {
/*
    //test1
    thread mythread1(print1);
    mythread1.join();
    cout << "主线程执行" << endl << endl;

    //test2
    int itm = 8;
    Test2 t(itm);
    thread mythread2(t);
    mythread2.join();//阻塞主线程,等待mythread2线程结束再执行主线程

    test3();
*/
    struct member *b;
    b = new struct member;
    b->age = 18;
    b->name = "libai";

    /*
     * pthread_create函数四个参数的含义
     * 第一个参数为指向线程标识符的指针。

　　第二个参数用来设置线程属性。

　　第三个参数是线程运行函数的地址。

　　最后一个参数是运行函数的参数。
     * */
    if(pthread_create(&test,NULL,pthread_test,(void *)b) == -1){
        cout << "create pthread error" << endl;
        return 1;
    }
    sleep(1);
    cout << "main pthread" << endl;
    if(pthread_join(test,NULL)){
        cout << "thread is not exit" << endl;
        return -2;
    }

    const  char *str = "hello I'm chinesche!";
    const char *substr = "he";
    int sum=0;
    my_strstr(str,substr,&sum);
    cout << sum << endl;
    return 0;
}