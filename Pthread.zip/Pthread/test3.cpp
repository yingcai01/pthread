//
// Created by zhoujun on 20-7-20.
//

/*
 * 用lambda表达式创建一个线程
 * */
#include "head.h"
void test3(){

    cout << endl;
    auto mylamthread = []{
        cout << "我的线程开始执行了" << endl;
        cout << "我的线程执行结束了" << endl;
    };
    thread mythread3(mylamthread);
    mythread3.join();
    cout << "主线程执行结束" << endl;
}
