//
// Created by zhoujun on 20-7-20.
//

#ifndef PTHREAD_HEAD_H
#define PTHREAD_HEAD_H

#include <iostream>
#include <thread>
#include <pthread.h>
#include <unistd.h>

#include <cstdio>
#include <cstdlib>
#include <cstring>
using namespace std;

#include "Test2.h"

struct member{
    int age;
    char *name;
};
#endif //PTHREAD_HEAD_H
