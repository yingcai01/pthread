//
// Created by zhoujun on 20-7-20.
//
#include "head.h"
/*
 * 用一个初始函数创建一个线程
 * */
void print1(){
    cout << "print1_1线程执行" << endl;
    cout << "print1_2线程执行" << endl;
    cout << "print1_3线程执行" << endl;
}
