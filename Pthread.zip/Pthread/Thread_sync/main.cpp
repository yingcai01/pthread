#include "sync_head.h"


int main() {
  // Mutex();
  //  mutex_condition();
  // condition_mutex();
   // rwlock_test1();
    //rwlock_test2();
    //
     //rwlock_pthread();
    //test_my_rwlock();
    //test_condwithmutex_to_rwlock();
    //proc_consum_cond();
    //spinlock_test();
    barrier_test();
    return 0;
}