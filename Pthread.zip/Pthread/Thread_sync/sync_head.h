//
// Created by zhoujun on 20-7-21.
//

#ifndef THREAD_SYNC_SYNC_HEAD_H
#define THREAD_SYNC_SYNC_HEAD_H


#include <iostream>
#include <unistd.h>
#include <pthread.h>
#include <cstdio>
#include <cerrno>
#include <semaphore.h>
#include <cassert>
#include <cstdlib>

using namespace std;

void Mutex();//互斥锁
void mutex_sem();//信号量
void condition_mutex();//条件变量
void proc_consum_cond();//条件变量：生产者消费者模型

void rwlock_test1();//读锁
void rwlock_test2();//写锁

void rwlock_pthread();//读写锁
class Readwrite_lock;//互斥量实现读写锁的类
void test_my_rwlock();//互斥量实现读写锁

void test_condwithmutex_to_rwlock();//互斥量和条件变量实现读写锁

void spinlock_test();//自旋锁

void barrier_test();//屏障

#endif //THREAD_SYNC_SYNC_HEAD_H
