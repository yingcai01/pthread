//
// Created by zhoujun on 20-7-21.
//
#include "sync_head.h"

int a =200;
int b = 100;

pthread_mutex_t lock;

void *ThreadA(void *){
    pthread_mutex_lock(&lock);//加上互斥锁

    a-= 50;
    sleep(5);//执行到一半,使用sleep,放弃CPU调度
    b+= 50;
    cout << "wait a 5 s" << endl;
    sleep(2);
    pthread_mutex_unlock(&lock);
}

void * ThreadB(void*){
    sleep(1);//在加锁前使用sleep函数，放弃CPU调度，使线程A先运行
    pthread_mutex_lock(&lock);
    cout << a+b << endl;
    pthread_mutex_unlock(&lock);

}

void Mutex(){
    pthread_t tida,tidb;
    pthread_mutex_init(&lock,NULL);
    pthread_create(&tida,NULL,ThreadA,NULL);
    pthread_create(&tidb,NULL,ThreadB,NULL);
    pthread_join(tida,NULL);
    pthread_join(tidb,NULL);
}
