//
// Created by zhoujun on 20-7-22.
//
#include "sync_head.h"

pthread_rwlock_t rwlock = PTHREAD_RWLOCK_INITIALIZER;


/*
 * 读是共享锁
 * */
void *thread_fun1(void *arg){
    pthread_rwlock_rdlock(&rwlock); //这里说明读锁是共享锁，即便没有解锁，thread_fun2也可以加读锁执行
    cout << "this is fun1." << endl;
}

void *thread_fun2(void *arg){
    pthread_rwlock_rdlock(&rwlock);
    cout << "this is fun2." << endl;
    pthread_rwlock_unlock(&rwlock);
}

void rwlock_test1(){
    pthread_t tid1,tid2;
    pthread_create(&tid1,NULL,thread_fun1,NULL);
    sleep(2);
    pthread_create(&tid2,NULL,thread_fun2,NULL);
    pthread_join(tid1,NULL);
    pthread_join(tid2,NULL);
}


/*
 * 写是独占锁
 * */
pthread_rwlock_t lockw = PTHREAD_RWLOCK_INITIALIZER;
void *thread_fun3(void *arg){
    pthread_rwlock_wrlock(&lockw); //这里写锁没有解锁，说明此线程没有执行完，则线程fun4难以执行
    cout << "this is fun1." << endl;
}

void *thread_fun4(void *arg){
    pthread_rwlock_wrlock(&lockw);//fun3没有解锁
    cout << "this is fun2." << endl;
    pthread_rwlock_unlock(&lockw);
}

void rwlock_test2(){
    pthread_t tid1,tid2;
    pthread_create(&tid1,NULL,thread_fun3,NULL);
    sleep(2);
    pthread_create(&tid2,NULL,thread_fun4,NULL);
    pthread_join(tid1,NULL);
    pthread_join(tid2,NULL);
}


#define THREAD_NUM 5

void *thread_fun(void *arg){//写锁
    pthread_rwlock_wrlock(&rwlock);
    cout << "thread fun lock write lock." << endl;
    sleep(10);
    pthread_rwlock_unlock(&rwlock);
    cout << "thread fun lock write unlock." << endl;
    cout << "thread fun end." << endl;
}
void *thread_fun_ar1(void *arg){//读锁
    int index = *(int *)arg;
    cout << "["<<index<<"] thread start up. " << __FUNCTION__<< endl;
    pthread_rwlock_rdlock(&rwlock);
    cout << "["<<index<<"] thread rdlock ." << __FUNCTION__<< endl;
    pthread_rwlock_unlock(&rwlock);
    cout << "rdlock _ end" << endl;
}
void *thread_fun_ar2(void *arg){//写锁
    int index = *(int *)arg;
    cout << "["<<index<<"] thread start up. " << __FUNCTION__<< endl;
    pthread_rwlock_wrlock(&rwlock);
    cout << "["<<index<<"] thread wrlock ." << __FUNCTION__<< endl;
    pthread_rwlock_unlock(&rwlock);
    cout << "wrlock _end" << endl;
}


/*
 * 我们先给一个线程（thread_fun()函数）分配写锁，用循环创建的其他线程都将被阻塞。调用sleep()函数延时，
 * 使得循环创建的五个进程都处于启动状态，然后解写锁。
 * 五个进程中有的要分配写锁，有的要分配读锁。
 * 多次执行程序，从运行的结果可以看出系统是优先分配写锁的。
 * */
void rwlock_pthread(){
    pthread_t tid;
    pthread_create(&tid, nullptr,thread_fun,NULL);
    sleep(1);
    pthread_t tid_ar[THREAD_NUM];
    for(int i = 0;i < 2;i++){
        pthread_create(&tid_ar[i],NULL,thread_fun_ar1,(void *)&i);
        sleep(1);
    }
    for(int i = 2;i < THREAD_NUM;i++){
        pthread_create(&tid_ar[i],NULL,thread_fun_ar2,(void *)&i);
        sleep(1);
    }
    pthread_join(tid,NULL);
    for(int i = 0;i < THREAD_NUM;i++)
        pthread_join(tid_ar[i],NULL);

}


