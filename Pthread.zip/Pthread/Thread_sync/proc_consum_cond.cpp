//
// Created by zhoujun on 20-7-24.
//

#include "sync_head.h"

typedef struct node{
    int data;
    struct node *next;
}node_t,*node_p,**node_pp;

pthread_mutex_t my_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t my_cond = PTHREAD_COND_INITIALIZER;

node_p InitNode(int data){
    auto node = (node_p)malloc(sizeof(node_t));
    if(nullptr == node){
        perror("malloc");
        return nullptr;
    }

    node->data = data;
    node->next = nullptr;
    return node;
}
void InitList(node_pp h){
    *h = InitNode(0);
}
void PushFrond(node_p list,int data){
    assert(list);

    node_p new_node = InitNode(data);
    new_node->next = list->next;
    list->next = new_node;
}

int IsEmpty(node_p list){
    if(nullptr == list->next)
        return 1;
    else
        return 0;
}

void DelNode(node_p node){
    assert(node);

    free(node);
}
void PopFrond(node_p list,int* data){
    assert(list);
    assert(data);

    if(IsEmpty(list)){
        cout << "list is empty..." << endl;
        return;
    }

    node_p delnode = list->next;
    list->next = delnode->next;
    *data = delnode->data;
    DelNode(delnode);
}

void DestroyList(node_p list){
    assert(list);

    int data = 0;
    while(!IsEmpty(list)){
        PopFrond(list,&data);
    }
    DelNode(list);
}

void Showlist(node_p list){
    node_p node = list->next;
    while(node){
        cout << node->data << " ";
        node = node->next;
    }
    cout <<endl;
}

void* thread_product(void* arg){
    node_p head = (node_p)arg;
    while(1){
        usleep(123456);
        pthread_mutex_lock(&my_mutex);

        int data = rand()%10000;
        PushFrond(head,data);//生产
        cout << "product done,data is: " << data << endl;
        pthread_mutex_unlock(&my_mutex);

        //生产出一个产品以后，唤醒一个消费者，通知消费者来取产品
        pthread_cond_signal(&my_cond);
    }
}

void* thread_consumer(void *arg){
    node_p node = (node_p)arg;
    int data = 0;
    while(1){
        pthread_mutex_lock(&my_mutex);
        if(IsEmpty(node)){
            //如果链表为空的话，那么等待生产者至少生产出一个产品后，才去取产品
            pthread_cond_wait(&my_cond,&my_mutex);
        }
        PopFrond(node,&data);//取产品
        cout << "consumer done,data is : " << data << endl;
        pthread_mutex_unlock(&my_mutex);
    }
}

void proc_consum_cond(){


    node_p head;
    InitList(&head);

    pthread_t tid1;
    pthread_t tid2;

    int ret1 = pthread_create(&tid1, nullptr,thread_product,(void *)head);
    int ret2 = pthread_create(&tid2, nullptr,thread_consumer,(void *)head);

    if(ret1 < 0 || ret2 < 0){
        perror("pthread_create");
        return;
    }

    pthread_join(tid1, nullptr);
    pthread_join(tid2, nullptr);

    DestroyList(head);
    pthread_mutex_destroy(&my_mutex);
    pthread_cond_destroy(&my_cond);
    /*
    node_p head;
    InitList(&head);
    for(int i = 0;i < 10;i++){
        //PopFrond(head,&i);
        PushFrond(head,i);
    }
    Showlist(head);
    int data = 0;
    for(int i =0;i<5;i++){
        PopFrond(head,&data);
        Showlist(head);
    }
    Showlist(head);*/
}