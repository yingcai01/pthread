//
// Created by zhoujun on 20-7-23.
//

#include "sync_head.h"

class Myrwlock{
public:
    Myrwlock(){
        pthread_mutex_init(&mutex,nullptr);
        pthread_cond_init(&cond, nullptr);
    }
    ~Myrwlock(){
        pthread_mutex_destroy(&mutex);
        pthread_cond_destroy(&cond);
    }

    void Readlock(){
        pthread_mutex_lock(&mutex);
        while(stat < 0 || have_wlock_wait)
            pthread_cond_wait(&cond,&mutex);
        ++stat;
        pthread_mutex_unlock(&mutex);
    }
    void Readunlock(){
        pthread_mutex_lock(&mutex);
        if(--stat == 0)
            pthread_cond_signal(&cond);
        pthread_mutex_unlock(&mutex);
    }
    void Writelock(){
        pthread_mutex_lock(&mutex);
        while(stat != 0){
            have_wlock_wait = true;
            pthread_cond_wait(&cond,&mutex);
        }
        stat = -1;
        have_wlock_wait = false;
        pthread_mutex_unlock(&mutex);
    }
    void Writeunlock(){
        pthread_mutex_lock(&mutex);
        stat = 0;
        pthread_cond_broadcast(&cond);
        pthread_mutex_unlock(&mutex);
    }

private:
    pthread_mutex_t mutex;
    pthread_cond_t cond;
    int stat;// == 0 not lock; > 0 read lock;  < 0 have write lock
    bool have_wlock_wait;
};

class MyRlockwrapper{
public:
    MyRlockwrapper(Myrwlock &lock){
        this->lock = lock;
        this->lock.Readlock();
    }
    virtual ~MyRlockwrapper(){
        lock.Readunlock();
    }

private:
    Myrwlock lock;
    MyRlockwrapper() = delete;
    MyRlockwrapper(const MyRlockwrapper &orig) = delete;
    MyRlockwrapper&operator=(const MyRlockwrapper &) = delete;
};
class MyWlockwrapper{
public:
    MyWlockwrapper(Myrwlock &lock){
        this->lock = lock;
        this->lock.Writelock();
    }
    ~MyWlockwrapper(){
        lock.Writeunlock();
    }
private:
    Myrwlock lock;
    MyWlockwrapper() = delete;//表示删除默认构造函数
    MyWlockwrapper(const MyWlockwrapper &orig) = delete;//delete表示删除默认
    MyWlockwrapper&operator=(const MyWlockwrapper &) = delete;
};

Myrwlock g_lock;

void *rfunc(void *pram){
    while(1){
        MyRlockwrapper lock(g_lock);
        cout << "at rfunc,[" << pthread_self() << "]" << endl;
        sleep(1);
    }
}

void *wfunc(void *pram){
    while(1){
        MyWlockwrapper lock(g_lock);
        cout << "at wfunc,[" << pthread_self() << "]" << endl;
        sleep(1);
    }
}

void test_condwithmutex_to_rwlock(){
    pthread_t rtid[1],wtid[1];
    for(int i =0;i<1;i++)
        pthread_create(&rtid[i],NULL,rfunc,NULL);
    for(int i =0;i<1;i++)
        pthread_create(&wtid[i],NULL,wfunc,NULL);
    pause();
}