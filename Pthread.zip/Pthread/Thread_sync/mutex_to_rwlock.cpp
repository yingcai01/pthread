//
// Created by zhoujun on 20-7-22.

//
/*以下的实现在多个写锁被阻塞时非常消耗计算机资源。
 * 因为线程阻塞在写锁中而没有被投入睡眠，导致轮询策略。
 * 避免轮询可通过互斥锁+条件变量实现读写锁
 * 仅使用互斥锁实现读写锁
 * */
#include "sync_head.h"

class Readwrite_lock{
public:
    Readwrite_lock();
    ~Readwrite_lock(){
        delete readCount;
    }
    void rdlock(){
        pthread_mutex_lock(&RDlock);
        (*readCount)++;
        if(*readCount == 1) //有人读，于是阻塞写锁
            pthread_mutex_lock(&WRlock);
        pthread_mutex_unlock(&RDlock);
    }

    void rdunlock(){
        pthread_mutex_lock(&RDlock);
        (*readCount)--;
        if(*readCount == 0)//表示已经没有人在读，释放写锁，可以写入了
            pthread_mutex_unlock(&WRlock);
        pthread_mutex_unlock(&RDlock);
    }
    void wrlock(){
        pthread_mutex_lock(&WRlock);
    }

    void wrunlock(){
        pthread_mutex_unlock(&WRlock);
    }

private:
    pthread_mutex_t RDlock{};
    pthread_mutex_t WRlock{};
    int *readCount;
};

Readwrite_lock::Readwrite_lock() {
    readCount = new int(0);
    pthread_mutex_init(&RDlock, nullptr);
    pthread_mutex_init(&WRlock, nullptr);
    //WRlock = PTHREAD_MUTEX_INITIALIZER;
}

void *fun(void *pram){
    cout << __FUNCTION__ << endl;
    class Readwrite_lock *ptr = (class Readwrite_lock *)pram;
    ptr->wrlock();
    sleep(10);
    cout << " fun_wrlock locked" << endl;
    ptr->wrunlock();
}

void *fun1(void *pram){
    cout << __FUNCTION__ << endl;
    class Readwrite_lock *ptr = (class Readwrite_lock *)pram;
    ptr->rdlock();
    cout << "rdlock locked" << endl;
    ptr->rdunlock();
}

void *fun2(void *pram){
    cout << __FUNCTION__ << endl;
    class Readwrite_lock *ptr = (class Readwrite_lock *)pram;
    ptr->wrlock();
    cout << "wrlock locked" << endl;
    ptr->wrunlock();
}
void test_my_rwlock(){
    class Readwrite_lock lock;
    pthread_t th;
    pthread_create(&th, nullptr,fun,(void *)&lock);
    pthread_t tid[5];
    for(int i =0;i < 3;i++){
        pthread_create(&tid[i], nullptr,fun1,(void *)&lock);
        sleep(1);
    }
    for(int i = 3;i<5;i++){
        pthread_create(&tid[i], nullptr,fun2,(void *)&lock);
    }

    for(int i = 0 ;i < 5;i++)
        pthread_join(tid[i], nullptr);
}

