//
// Created by zhoujun on 20-7-25.
//

#include "sync_head.h"

pthread_barrier_t g_barrier;


void *Func(void *arg){
    long id ;
    id = reinterpret_cast<long>(arg);
    if(id == 0){
        cout << "thread 0" << endl;
        sleep(1);
        pthread_barrier_wait(&g_barrier);
        cout << "thread 0 come ..." << endl;
    }else if(id == 1){
        cout << "thread 1" << endl;
        sleep(2);
        pthread_barrier_wait(&g_barrier);
        cout << "thread 1 come ..." << endl;
    }else if(id == 2){
        cout << "thread 2" << endl;
        sleep(3);
        pthread_barrier_wait(&g_barrier);
        cout << "thread 2 come ..." << endl;
    }
}
void *(*p)(void *);
void barrier_test(){
    pthread_t t[3];

    p = Func;
    pthread_barrier_init(&g_barrier, nullptr,3);
    for(int i = 0; i < 3;i++)
        pthread_create(&t[i], nullptr,p,(void *)i);

    for (unsigned long i : t)
        pthread_join(i, nullptr);

}