//
// Created by zhoujun on 20-7-21.
//

/*
 * 实现功能: 2个线程对count每次分别加1, 第三个线程等count大于10后一次加100.
 * */
#include "sync_head.h"
#define NUM_THREADS 4
#define TCOUNT 20
#define COUNT_LIMIT 10

int count = 0;
int thread_ids[NUM_THREADS] = {0,1,2,3};
pthread_mutex_t count_mutex;
pthread_cond_t count_threshold_cv; //= PTHREAD_COND_INITIALIZER;

void *inc_count(void *idp){
    int i = 0;
    //int taskid = 0;
    int *m_id =(int *)idp;
    for(i=0;i < TCOUNT;i++){
        pthread_mutex_lock(&count_mutex);//pthread_cond_signal必须在互斥锁的保护下使用相应的条件变量。
        //taskid = count;
        count++;

        //pthread_cond_signal应该在互斥锁的保护下
        pthread_cond_signal(&count_threshold_cv);//当没有线程阻塞在条件变量上，此函数将没有作用，所以在加100后
                                                // 此线程还会继续运行此循环TCOUNT次

        cout << "inc_count() : thread " << *m_id << ",count = " << count <<",unlocking mutex" << endl;
        pthread_mutex_unlock(&count_mutex);
        sleep(1);
    }

    cout << "inc_count() : thread " << *m_id <<",Threshold reached" << endl;

    pthread_exit(nullptr);
}

void *watch_count(void *idp){
    int *m_id = (int *)idp;

    cout << "Strating watch(): thread "<< *m_id << endl;

    pthread_mutex_lock(&count_mutex);
    while(count < COUNT_LIMIT){
        sleep(3);

        pthread_cond_wait(&count_threshold_cv,&count_mutex);//即使此函数返回出错，但是相应的互斥锁还是会被锁定
        cout << "watch_count():thread " << *m_id << " Condition signal received." <<endl;
    }

    count += 100;
    pthread_mutex_unlock(&count_mutex);
    pthread_exit(NULL);
}

void condition_mutex(){
    int i,rc;
    pthread_t threads[NUM_THREADS];
    pthread_attr_t attr;//函数地址

    //初始化互斥锁和条件变量
    pthread_mutex_init(&count_mutex,NULL);
    pthread_cond_init(&count_threshold_cv,NULL); //count_threshold_cv= PTHREAD_COND_INITIALIZER;

    pthread_attr_init(&attr);
    pthread_attr_setdetachstate(&attr,PTHREAD_CREATE_JOINABLE);
    //
    pthread_create(&threads[0],&attr,inc_count,(void *)&thread_ids[0]);
    pthread_create(&threads[1],&attr,inc_count,(void *)&thread_ids[1]);
    pthread_create(&threads[2],&attr,inc_count,(void *)&thread_ids[2]);//3个线程+1,运行一次加3,则是9<10,12>10
    pthread_create(&threads[3],&attr,watch_count,(void *)&thread_ids[3]);
   //

    for(i=0;i<NUM_THREADS;i++){
        pthread_join(threads[i],NULL);
    }
    printf ("Main(): Waited on %d  threads. Done.\n", NUM_THREADS);
    pthread_attr_destroy(&attr);
    pthread_mutex_destroy(&count_mutex);
    pthread_cond_destroy(&count_threshold_cv);
    pthread_exit(NULL);
}