//
// Created by zhoujun on 20-7-25.
//

#include "sync_head.h"

pthread_spinlock_t spin_lock;
int data = 0;
//pthread_mutex_t mu = PTHREAD_MUTEX_INITIALIZER;
void *func(void *arg){
    /**/
    while(1){
        pthread_spin_lock(&spin_lock);
        //pthread_mutex_lock(&mu);
        data++;
        cout << "-----------" << data <<endl;
        sleep(1);
        //pthread_mutex_unlock(&mu);
        pthread_spin_unlock(&spin_lock);
    }
}

void spinlock_test(){
    pthread_t tid;
    pthread_spin_init(&spin_lock, PTHREAD_PROCESS_PRIVATE);
    for(int i =0;i<3;i++)
        pthread_create(&tid, nullptr,func, nullptr);
    pthread_join(tid, nullptr);
}