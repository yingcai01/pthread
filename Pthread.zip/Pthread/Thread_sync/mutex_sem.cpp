//
// Created by zhoujun on 20-7-21.
//
#include "sync_head.h"

pthread_mutex_t poll_work;//互斥锁
sem_t poll_in;//水池容量信号量
sem_t poll_out;//当前水量信号量


//sem_wait 信号量减少1
//sem_post 信号量增加1
void* thread0(void *parm){ //0线程往水池中加水。
    while(1){
        int rv = 0;
        for(int i = 0;i < 5; i++)
            while((rv = sem_wait(&poll_in)) != 0 && (errno == EINTR))//水量增加5,循环使得容量信号量减少5
                ;

        pthread_mutex_lock(&poll_work);//加锁,线程互斥

        (*(int*)parm) += 5;
        cout << "Thread0 : " << (*(int*)parm) << endl;
        for(int i = 0;i < 5;i++){
            sem_post(&poll_out);//增加当前水量信号量
        }
        pthread_mutex_unlock(&poll_work);//解锁

        sleep(1);
    }
    return NULL;
}

void* thread1(void *parm){//1线程往水池加水
    while(1){
        int rv = 0;
        for(int i = 0;i < 4; i++)
            while((rv = sem_wait(&poll_in)) != 0 && (errno == EINTR))
                ;

        pthread_mutex_lock(&poll_work);

        (*(int*)parm) += 4;
        cout << "Thread1 : " << (*(int*)parm) << endl;
        for(int i = 0;i < 4;i++){
            sem_post(&poll_out);
        }
        pthread_mutex_unlock(&poll_work);

        sleep(1);
    }
    return NULL;
}

void* thread2(void *parm){//此线程用于将水从水池中倒出
    while(1){
        int rv = 0;
        for(int i = 0;i < 3; i++)
            while((rv = sem_wait(&poll_out)) != 0 && (errno == EINTR))//减少当前水量
                cout << "xx";

        pthread_mutex_lock(&poll_work);

        (*(int*)parm) -= 3;
        cout << "Thread2 : " << (*(int*)parm) << endl;
        for(int i = 0;i < 3;i++){
            sem_post(&poll_in);//水池容量信号量增加
        }
        pthread_mutex_unlock(&poll_work);

        sleep(1);
    }
    return NULL;
}

void mutex_sem(){
    int sum = 0;//水深，初始化 水池里面没有水
    int i;

    pthread_mutex_init(&poll_work,NULL);
    sem_init(&poll_in,0,100);//水满为100
    sem_init(&poll_out,0,sum);
    pthread_t th[4];
    pthread_create(&th[0],NULL,thread0,(void *)&sum);
    pthread_create(&th[1],NULL,thread1,(void *)&sum);
    pthread_create(&th[2],NULL,thread2,(void *)&sum);
    for(i = 0; i < 3;i++)
        pthread_join(th[i],NULL);
}