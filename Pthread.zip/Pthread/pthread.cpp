//
// Created by zhoujun on 20-7-20.
//
#include "head.h"
void *pthread_test(void * arg){
    struct member *temp;
    cout << "线程开始运行" << endl;
    sleep(2);
    temp = (struct member*)arg;
    cout << temp->age << ":" << temp->name << endl;
    return NULL;
}