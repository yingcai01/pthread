//
// Created by zhoujun on 20-7-20.
//
#include <iostream>
using  namespace std;
#ifndef PTHREAD_TEST2_H
#define PTHREAD_TEST2_H

/*
 * 用类对象创建一个对象
 * */
class Test2 {
public:
    int it;
    Test2(int m_it):it(m_it){
        cout << "构造函数被执行" << endl;
    }
    Test2(const Test2 &t):it(t.it){
        cout << "拷贝构造函数被执行" << endl;
    }
    ~Test2(){
        cout << "析构函数被执行" << endl;
    }
    void operator()(){
        cout << "it值：" << it << endl;
    }
};


#endif //PTHREAD_TEST2_H
